﻿using System;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Net.Http.Json;

namespace UdpBroadcastCapture
{
    public class Lokale
    {
        public string lokaleId { get; set; }
        public int? cardId { get; set; }
    }
    class Program
    {
        // https://msdn.microsoft.com/en-us/library/tst0kwb1(v=vs.110).aspx
        // IMPORTANT Windows firewall must be open on UDP port 7000
        // https://www.windowscentral.com/how-open-port-windows-firewall
        // Use the network MGV-xxx to capture from local IoT devices (fake or real)
        private const int Port = 7221;
        private static readonly IPAddress IpAddress = IPAddress.Parse("192.168.24.201"); 
        // Listen for activity on all network interfaces
        // https://msdn.microsoft.com/en-us/library/system.net.ipaddress.ipv6any.aspx
        static void Main()
        {
            IPEndPoint ipEndPoint = new IPEndPoint(IpAddress, Port);
            using (UdpClient socket = new UdpClient(ipEndPoint))
            {
                IPEndPoint remoteEndPoint = new IPEndPoint(0, 0);
                while (true)
                {
                    Console.WriteLine("Waiting for broadcast {0}", socket.Client.LocalEndPoint);
                    byte[] datagramReceived = socket.Receive(ref remoteEndPoint);

                    string message = Encoding.ASCII.GetString(datagramReceived, 0, datagramReceived.Length);
                    Console.WriteLine("Receives {0} bytes from {1} port {2} message {3}", datagramReceived.Length,
                        remoteEndPoint.Address, remoteEndPoint.Port, message);
                    ParseAndSendAsync(message);
                }
            }
        }
        static HttpClient client = new HttpClient();
        //private static async void ParseAndSend(string message)
        //{ //{"Lokale.lokaleId":"D2.09", "Lokale.cardId":Null}$1
        //    string lokaleJson = message.Split('$')[0];
        //    Lokale lokale = JsonSerializer.Deserialize<Lokale>(lokaleJson);
        //    JsonContent serializedItem = JsonContent.Create(lokale);
        //    Console.WriteLine($"https://restogtests20221210170609.azurewebsites.net/api/Lokale/{lokale.lokaleId}");
        //    Console.WriteLine(serializedItem);
        //    HttpResponseMessage response = await client.PutAsync(
        //        $"https://restogtests20221210170609.azurewebsites.net/api/Lokale/{lokale.lokaleId}", serializedItem);
        //    Console.WriteLine(response);

        //}

        private static async Task ParseAndSendAsync(string message)
        {
            // Extract the JSON string from the message
            string lokaleJson = message.Split('$')[0];

            // Deserialize the JSON string into a Lokale object
            Lokale lokale = JsonSerializer.Deserialize<Lokale>(lokaleJson);

            // Create a JSON content object from the Lokale object
            JsonContent serializedItem = JsonContent.Create(lokale);

            // Construct the URL for the HTTP PUT request
            string url = $"https://restogtests20221210170609.azurewebsites.net/api/Lokale/{lokale.lokaleId}";

            // Send the HTTP PUT request and await the response
            HttpResponseMessage response = await client.PutAsync(url, serializedItem);

            // Print the response to the console
            Console.WriteLine(response);
        }
    }
}
